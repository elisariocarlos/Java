/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bibliotecamathfloor;

/**
 *
 * @author Elisário Carlos
 */
import java.math.MathContext;
public class BibliotecaMathFloor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double a=Math.random();
        System.out.println(a);
    }
    
}
