/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio.array.itel;

import java.util.Scanner;

/**
 *
 * @author Elisário Carlos
 * 
 * Faça um programa em java que armazene as notas de uma turma e calcule a média ponderada,
além de identificar quantos alunos passaram ou não.
Requisitos:
• O programa deve solicitar ao usuário o número de alunos na turma.
• Para cada aluno, o programa deve pedir: a nota do exame (peso 60%) e a nota da classificação
final(peso 40%)
• O programa deve contar quantos alunos foram aprovados ou reprovados com base a média
ponderada.
• Exiba a média ponderada e o status(aprovado ou reprovado) para cada aluno, além do total
aprovados e reprovados na turma.
 */
public class ExercicioArrayITEL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        System.out.println("Digite o número de alunos da turma");
        System.out.print("---> ");
        int numeroDeAlunosDaTurma=leia.nextInt();
        
        double[] mediaArray=new double[numeroDeAlunosDaTurma];
        String[] resultado=new String[numeroDeAlunosDaTurma];
        int numerosDeAprovados=0;
        int numerosDeReprovados=0;
        double maiorMedia=0,menorMedia=0;
        int numeroDoAlunoComMaiorMedia=0,numeroDoAlunoComMenorMedia=0;
        
        System.out.println("");
        
        for(int i=1; i<=numeroDeAlunosDaTurma;i++){
            System.out.println("==== Aluno "+i+" ====");
            System.out.println("Digite a nota do exame");
            System.out.print("---> ");
            double notaDoExame=leia.nextDouble();
            System.out.println("Digite a nota final");
            System.out.print("---> ");
            double notaFinal=leia.nextDouble();
            double media=(notaDoExame+notaFinal)/2;
            mediaArray[i-1]=media;
            if(media<10){
                resultado[i-1]="Reprovado";
                numerosDeReprovados++;
            }
            else{
                resultado[i-1]="Aprovado";
                numerosDeAprovados++;
            }
            if(numeroDeAlunosDaTurma>1){
                 if(media>maiorMedia){
                     maiorMedia=media;
                     numeroDoAlunoComMaiorMedia=i;
                    }
                 if(i==1){
                   menorMedia=media;
                     numeroDoAlunoComMenorMedia=i;
                 }
                 if(media<menorMedia){
                     menorMedia=media;
                     numeroDoAlunoComMenorMedia=i;
                 }
            }
            
            
            
            System.out.println("\n"); 
        }
        System.out.println("==== Resultado Individuais ====");
        
        for(int i=1; i<=numeroDeAlunosDaTurma ; i++){              
              System.out.println("     Aluno "+i+"");
              System.out.println("Média: "+mediaArray[i-1]);
              System.out.println("Resultado: "+resultado[i-1]);
              System.out.println("-------------------------------");
              System.out.println("");
        }
        System.out.println("");
        System.out.println("==== Resultados Gerais ====");
        System.out.println("Números de Alunos: "+numeroDeAlunosDaTurma);
        System.out.println("Números de Aprovados: "+numerosDeAprovados);
        System.out.println("Números de Reprovados: "+numerosDeReprovados);
       
        if(numeroDeAlunosDaTurma>1){
             System.out.println("Maior Média: "+maiorMedia);
             System.out.println("Número do Aluno Com Maior Média: "+numeroDoAlunoComMaiorMedia);
        System.out.println("Menor Média: "+menorMedia);
        System.out.println("Número do Aluno Com Menor Média: "+numeroDoAlunoComMenorMedia);
        }
        
        
    }
    
}
