package metodos_array.inteiro.e.escreve.o.maior.numero;
/**
     *Implemente um método que receba um
      array de inteiros e retorne o maior valor.
    * @author Elisário Carlos
*/
public class Metodos_ArrayInteiroEEscreveOMaiorNumero {
       // Método que encontra o maior valor em um array de inteiros
    public static int encontrarMaiorValor(int[] array) {
        // Inicializa a variável maior com o primeiro valor do array
        int maior = array[0];

        // Loop para percorrer todos os elementos do array
        for (int i = 1; i < array.length; i++) {
            // Verifica se o valor atual é maior que o valor armazenado em maior
            if (array[i] > maior) {
                maior = array[i];
            }
        }

        // Retorna o maior valor encontrado
        return maior;
    }

    public static void main(String[] args) {
        // Exemplo de uso do método
        int[] numeros = {-1, -2, -3, -8};
        int maiorValor = encontrarMaiorValor(numeros);

        System.out.println("O maior valor do array é: " + maiorValor);
    }

    
}
