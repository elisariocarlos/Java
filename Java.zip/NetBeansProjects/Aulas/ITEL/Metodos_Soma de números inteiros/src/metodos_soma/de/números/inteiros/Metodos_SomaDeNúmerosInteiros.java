package metodos_soma.de.números.inteiros;

import java.util.Scanner;

/**
     *Crie um método que receba dois
      números inteiros como parâmetros e
      retorne a soma deles.
  * @author Elisário Carlos
*/
public class Metodos_SomaDeNúmerosInteiros {
    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        int a,b;
        System.out.println("Digite o primeiro número para realizar a soma");
        System.out.print("---> ");
        a=leia.nextInt();
        System.out.println("");
        System.out.println("Digite o segundo número para realizar a soma");
        System.out.print("---> ");
        b=leia.nextInt();        
        System.out.println(a+" + "+b+" = "+soma(a,b));
    }
    
    public static int soma(int num1,int num2){
        return num1+num2;
    }
    
}
