/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package joption;

/**
 *
 * @author Elisário Carlos
 */
import javax.swing.JOptionPane;
public class Joption {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          // Caixa de diálogo de mensagem (mensagem simples)
        JOptionPane.showMessageDialog(null, "Bem-vindo ao nosso programa!", "Mensagem", JOptionPane.INFORMATION_MESSAGE);
        
        // Caixa de diálogo de entrada (solicita o nome do usuário)
        String nome = JOptionPane.showInputDialog("Qual é o seu nome?");
        
        // Caixa de diálogo de confirmação (pergunta ao usuário se ele deseja continuar)
        int opcao = JOptionPane.showConfirmDialog(null, "Você deseja continuar?", "Confirmar", JOptionPane.YES_NO_OPTION);
        
        // Mostrar uma mensagem com o nome do usuário e a resposta da confirmação
        if (opcao == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(null, "Olá, " + nome + "! Você escolheu continuar.", "Resposta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Olá, " + nome + "! Você escolheu não continuar.", "Resposta", JOptionPane.INFORMATION_MESSAGE);
        }
        }
    }
    

