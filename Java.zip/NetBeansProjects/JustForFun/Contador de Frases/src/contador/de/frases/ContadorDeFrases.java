
package contador.de.frases;

import java.util.Scanner;
public class ContadorDeFrases {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        System.out.println("Digite uma frase");
        System.out.print("---> ");
        String frase=leia.nextLine();
        String[] divisao=frase.split(" ");     
        System.out.println("A frase tem "+divisao.length+ " palavra");
    }
    
}
