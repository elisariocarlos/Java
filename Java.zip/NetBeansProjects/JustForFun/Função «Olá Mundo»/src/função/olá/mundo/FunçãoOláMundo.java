package função.olá.mundo;
public class FunçãoOláMundo {

    public static void main(String[] args) {
        olaMundo("Elisário Carlos");
    }
    
    public static void olaMundo(String nome){
        System.out.println("Olá "+nome);
    }
    
}
