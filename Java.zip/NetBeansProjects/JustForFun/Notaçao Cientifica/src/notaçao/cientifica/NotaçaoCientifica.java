/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package notaçao.cientifica;
import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author Elisário Carlos
 */
public class NotaçaoCientifica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Solicitar ao usuário que insira um número decimal
        System.out.print("Digite um número decimal: ");
        double numero = scanner.nextDouble();
        
        // Converter o número para notação científica usando DecimalFormat
        DecimalFormat formato = new DecimalFormat("0.0#####E0");
        
        // Exibir o número na notação científica
        System.out.println("Número em notação científica: " + formato.format(numero));
        
        // Fechar o scanner
        scanner.close();
    }
    
}
