/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numerosparesde0a100;

/**
 *
 * @author Elisário Carlos
 */
public class NumerosParesDe0A100 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int a=0; a<=100; a+=2){
            System.out.println(a);
        }
    }
    
}
