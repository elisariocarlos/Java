package ordenar.numeros.em.ordem.crescente;

import java.util.Scanner;

public class OrdenarNumerosEmOrdemCrescente {

    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        for(int i=1; i<=3; i++){
            System.out.println("Digite o "+i+" numero");
            System.out.print("---> ");
            int numero=leia.nextInt();
        }
    }
    
}
