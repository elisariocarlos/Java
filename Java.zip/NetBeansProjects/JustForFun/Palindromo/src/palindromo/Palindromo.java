/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palindromo;

/**
 *
 * @author Elisário Carlos
 */
import java.util.Scanner;
public class Palindromo {

    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        System.out.println("Digite uma palavra para verificar se uma palavra é palindromo ou não");
        System.out.print("---> ");
        String palavra = leia.nextLine();  // Palavra a ser verificada

        // Chama a função que verifica se a palavra é um palíndromo
        if (isPalindromo(palavra)) {
            System.out.println(palavra + " é um palíndromo.");
        } else {
            System.out.println(palavra + " não é um palíndromo.");
        }
    }

    // Função que verifica se uma palavra é um palíndromo
    public static boolean isPalindromo(String palavra) {
        // Converte a palavra para minúsculas para evitar a diferenciação entre maiúsculas e minúsculas
        palavra = palavra.toLowerCase();

        // Percorre a palavra e compara os caracteres da frente com os de trás
        int inicio = 0;
        int fim = palavra.length() - 1;

        while (inicio < fim) {
            // Se os caracteres não forem iguais, não é um palíndromo
            if (palavra.charAt(inicio) != palavra.charAt(fim)) {
                return false;
            }
            inicio++;
            fim--;
        }

        // Se passou por todas as comparações, é um palíndromo
        return true;
    }
}
    

