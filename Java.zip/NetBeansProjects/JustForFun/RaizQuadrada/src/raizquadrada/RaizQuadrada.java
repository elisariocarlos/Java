/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package raizquadrada;

/**
 *
 * @author Elisário Carlos
 */
import java.util.Scanner;
public class RaizQuadrada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leia=new Scanner(System.in);
        System.out.println("Digite um número para saber sua raíz quadrada");
        System.out.print("---> ");
        int numero=leia.nextInt();
       double raiz=Math.sqrt(numero);
        System.out.println("√"+numero+" = "+raiz);
    }
    
}
