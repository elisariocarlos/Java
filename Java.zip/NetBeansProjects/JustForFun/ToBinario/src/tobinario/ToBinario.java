/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tobinario;

/**
 *
 * @author Elisário Carlos
 */
import java.util.ArrayList;
import java.util.Scanner;
public class ToBinario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArrayList <Integer> restos = new ArrayList<>();
       Scanner leia=new Scanner(System.in);
        System.out.println("Digite um número decimal para mostrar seu valor em binário");
        System.out.print("---> ");
        int num=leia.nextInt();
        int numero=num;
        for(int i=0; numero>=2 ; i++){
            int resto=numero%2;
            numero=numero/2;
            restos.add(resto);
        }
        
        System.out.print("|"+num+"| em binário é --> [");
        System.out.print(numero);
        for(int i=restos.size(); i>0; i--){
          System.out.print(restos.get(i-1));
        }
        System.out.print("]");
        System.out.println("");
        
       

    }
    
}
