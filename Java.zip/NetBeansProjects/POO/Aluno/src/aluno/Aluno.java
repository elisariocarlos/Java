/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aluno;

/**
 *
 * @author Elisário Carlos
 */
import java.util.Scanner;
public class Aluno {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner ler=new Scanner(System.in);
        DadosDoAluno aluno1=new DadosDoAluno();
        System.out.print("Digite o nome do aluno: ");
        String nomeDoAluno=ler.nextLine();
        aluno1.nome=nomeDoAluno;
        aluno1.mostrarDadosDoAluno();
    }
    
}
