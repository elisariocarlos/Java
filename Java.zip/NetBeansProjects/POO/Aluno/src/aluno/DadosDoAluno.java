/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aluno;

/**
 *
 * @author Elisário Carlos
 */
public class DadosDoAluno {
    String nome;
    int idade;
    char sexo;
    
    void mostrarDadosDoAluno(){
        System.out.println("O nome do aluno é: "+this.nome);
    }
}
