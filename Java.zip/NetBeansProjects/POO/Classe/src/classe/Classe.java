/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classe;

/**
 *
 * @author Elisário Carlos
 */

class Animal {
    // Atributos (propriedades)
    String nome;
    int idade;

    // Construtor
    public Animal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }

    // Método (comportamento)
    public void falar() {
        System.out.println("O animal faz um som.");
    }
}

class Cachorro extends Animal {

    // Construtor
    public Cachorro(String nome, int idade) {
        super(nome, idade);  // Chama o construtor da superclasse
    }

    // Sobrescreve o método falar
    @Override
    public void falar() {
        System.out.println("O cachorro late!");
    }
    // Método específico de Cachorro
    public void correr() {
        System.out.println(nome + " está correndo.");
    }
}

class Gato extends Animal {

    // Construtor
    public Gato(String nome, int idade) {
        super(nome, idade);  // Chama o construtor da superclasse
    }

    // Sobrescreve o método falar
    @Override
    public void falar() {
        System.out.println("O gato mia!");
    }

    // Método específico de Gato
    public void escalar() {
        System.out.println(nome + " está escalando.");
    }
}


public class Classe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Criando objetos de Cachorro e Gato
        Animal meuCachorro = new Cachorro("Rex", 3);
        Animal meuGato = new Gato("Mia", 2);

        // Chamando métodos comuns
        System.out.println(meuCachorro.nome + " tem " + meuCachorro.idade + " anos.");
        meuCachorro.falar();  // Polimorfismo: método sobrescrito
        System.out.println(meuGato.nome + " tem " + meuGato.idade + " anos.");
        meuGato.falar();  // Polimorfismo: método sobrescrito

        // Chamando métodos específicos
        if (meuCachorro instanceof Cachorro) {
            ((Cachorro) meuCachorro).correr();  // Cast para chamar método específico
        }

        if (meuGato instanceof Gato) {
            ((Gato) meuGato).escalar();  // Cast para chamar método específico
        }
    }
}
    
    

