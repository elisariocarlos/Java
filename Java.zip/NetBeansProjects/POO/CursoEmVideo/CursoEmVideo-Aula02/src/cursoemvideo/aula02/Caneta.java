package cursoemvideo.aula02;
public class Caneta {
    String modelo;
    String cor;
    float ponta;
    int carga;
    boolean tampa;
    
    void rabiscar(){
        if(this.tampa==false && this.carga>0 && this.ponta>0){
            System.out.println("Escrevendo...");
        }
        else if(this.tampa==true){
            System.out.println("Impossível escrever, primeiro tire a tampa!");
        }
        else if(this.carga<=0){
            System.out.println("A lapiseira não tem carga!. Impossivel escrever");
        }
        else if(this.ponta<=0){
            System.out.println("A lapiseira não tem ponta!. Impossivel escrever");
        }
        //System.out.println("Erro! Ou tire a tampa ou mete");
    }
    
    void status(){
        System.out.println("Modelo: "+this.modelo);
        System.out.println("Cor "+this.cor);
        System.out.println("Ponta: "+this.ponta);
        System.out.println("Carga da lapiseira: "+this.carga);
        String tampadaOuDestampada=(this.tampa==false) ? "Destampada" : "Tampada";
        System.out.println("A lapiseira está: "+tampadaOuDestampada);
    }
    
    void tampar(){
        this.tampa=true;
    }
    
    void destampar(){
        this.tampa=false;
    }
}
