package cursoemvideo.aula02;
public class CursoEmVideoAula02 {
    //Fundamentos de Programação Orientada a objecto
    //Classes, metodos, atributos e construção de objectos
    public static void main(String[] args) {
        Caneta caneta1=new Caneta();
        caneta1.modelo="Bravo";
        caneta1.cor="Azul";
        caneta1.ponta=3.5f;
        caneta1.carga=0;
        caneta1.destampar();
        caneta1.rabiscar();
        caneta1.status();

    }
    
}
