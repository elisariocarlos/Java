package cursoemvideo.aula02;
public class Caneta {
    public String modelo; //Atributo publico
    public String cor; //Atributo publico
    private float ponta; //Atributo privado
    protected int carga; //Atributo protegido
    protected boolean tampa; //Atributo protegido
    
    public void rabiscar(){ //Metodo publico
        if(this.tampa==false && this.carga>0 && this.ponta>0){
            System.out.println("Escrevendo...");
        }
        else if(this.tampa==true){
            System.out.println("Impossível escrever, primeiro tire a tampa!");
        }
        else if(this.carga<=0){
            System.out.println("A lapiseira não tem carga!. Impossivel escrever");
        }
        else if(this.ponta<=0){
            System.out.println("A lapiseira não tem ponta!. Impossivel escrever");
        }
        //System.out.println("Erro! Ou tire a tampa ou mete");
    }

    
    public void status(){ //Metodo publico
        System.out.println("Modelo: "+this.modelo);
        System.out.println("Cor "+this.cor);
        System.out.println("Ponta: "+this.ponta);
        System.out.println("Carga da lapiseira: "+this.carga);
        String tampadaOuDestampada=(this.tampa==false) ? "Destampada" : "Tampada";
        System.out.println("A lapiseira está: "+tampadaOuDestampada);
    }
    
    private void tampar(){ //Metodo privado
        this.tampa=true;
    }
    
    private void destampar(){ //Metodo privado
        this.tampa=false;
    }
}

