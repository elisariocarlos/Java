package cursoemvideo.aula02;
public class CursoEmVideoAula02 {
    //Fundamentos de Programação Orientada a objecto
    //Classes, metodos, atributos e construção de objectos
    //Entendendo metodos e atributos(públicos, privados e protegidos)
    public static void main(String[] args) {
        Caneta caneta1=new Caneta();
        caneta1.modelo="Bravo";
        caneta1.cor="Azul";
        //caneta1.ponta=12f; Não conseguimos mexer em atributos privados
        caneta1.carga=13;
        //caneta1.tampar(); Não conseguimos chamar metodos privados 
        caneta1.rabiscar();
        caneta1.status();

    }
    
}
