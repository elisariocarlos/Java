
package cursoemvideo.aula04;

public class CursoEmVideoAula04 {

    //Metodos Especiais
    //Getters
    //Setters
    //Construtores
    public static void main(String[] args) {
        Caneta c1=new Caneta("Bravo","Azul",2.1f);
        Caneta c2=new Caneta("Stylo","Preta",1.9f);
        Caneta c3=new Caneta("BIC","Vermelha",0.99f);
    }
    
}
