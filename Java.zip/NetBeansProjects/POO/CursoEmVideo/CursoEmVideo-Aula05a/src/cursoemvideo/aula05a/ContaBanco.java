package cursoemvideo.aula05a;
public class ContaBanco {
    public int numConta;
    protected String tipo;
    private String dono;
    private double saldo;
    private boolean status;
    
    public ContaBanco(){
        this.status=false;
        this.saldo=0;
        System.out.println("Abre uma Conta e defina o tipo da conta:");
        System.out.println("|CP| - Conta Poupança");
        System.out.println("|CC| - Conta Corrente");
        System.out.print("--> ");
    }
    
    public void abrirConta(String tipoDaConta){
        setTipo(tipoDaConta);
        setStatus(true);
        if(getTipo()=="CP" || getTipo()=="cp"){
            setSaldo(50);
            System.out.println("Abriu uma Conta Poupança");
        }
        else if(getTipo()=="CC" || getTipo()=="cc"){
            setSaldo(150);
            System.out.println("Abriu uma Conta Crédito");
        }
      System.out.println("-----------------------------------");  
        
    }
    
    public void fecharConta(){
        if(getSaldo()>0){
            System.out.println("Não pode fechar a sua conta pois te dinheiro nela!");
        }
        else if(getSaldo()<0){
            System.out.println("A sua conta está com débito não podes fechar");
        }
        else{
            System.out.println("Fechando a conta....");
            System.out.println("Conta Fechada com sucesso");
            setStatus(false);
        }
        System.out.println("-----------------------------------");
    }
    
    public void depositar(double valor){
        if(isStatus()==true){
            setSaldo(getSaldo()+valor);
            System.out.println("Depositaste "+valor);
            System.out.println("Saldo Actual: "+getSaldo());
        }
        else{
            System.out.println("Não pode depositar não tem uma conta");
        }
        System.out.println("-----------------------------------");
    }
    
    public void sacar(double valor){
        if(isStatus()==true){
            if(getSaldo()>=valor){
                setSaldo(getSaldo()-valor);
                System.out.println("Retiraste "+valor);
                System.out.println("Saldo Actual: "+getSaldo());
            }
            else{
                System.out.println("Não dinheiro suficiente na conta para tirar este dinheiro.");
                System.out.println("Só podes tirar até "+getSaldo());
            }
        }
        else{
            System.out.println("Não pode sacar não tem uma conta");
        }
        System.out.println("-----------------------------------");
    }
    
    public void pagarMensal(){
        double valor=0;
        if(getTipo()=="CC"){
            valor=12;
        }
        else if(getTipo()=="CP"){
            valor=20;
        }
        if(isStatus()==true){
            if(getSaldo() > valor){
                setSaldo(getSaldo()-valor);
                System.out.println("A sua mensalidade foi paga!");
                System.out.println("Foste descontado: "+valor);
                System.out.println("Saldo Actual: "+getSaldo());
            }
            else{
                System.out.println("Impossivel pagar mensalidade dinheiro insuficiente");
            }
        }
        else{
            System.out.println("A sua conta está fechada");
        }
        
    }

    public int getNumConta() {
        return numConta;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
    
    public void info(){
        System.out.println("\n\n***********************************");
        String tipoDaConta="Indefinido";
        if(getTipo()=="CC" || getTipo()=="CP"){
            tipoDaConta=(getTipo()=="CC"?"Conta Corrente":"Conta Poupança");
        }
        String estadoDaConta=(isStatus()==true?"Activo(Aberta)":"Inativa(Fechada)");
        
        System.out.println("Nome do dono: "+getDono());
        System.out.println("Número da conta: "+ getNumConta());
        System.out.println("Saldo da conta: "+getSaldo());
        System.out.println("Tipo da Conta: "+tipoDaConta);
        System.out.println("Estado da conta: "+estadoDaConta);
    }
    
    
}
