package cursoemvideo.aula05a;
public class CursoEmVideoAula05a {
    public static void main(String[] args) {
        ContaBanco conta1=new ContaBanco();
        conta1.abrirConta("CC");
        conta1.info();
    }
    
}
