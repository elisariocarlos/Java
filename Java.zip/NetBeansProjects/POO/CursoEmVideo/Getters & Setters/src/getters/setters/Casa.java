package getters.setters;
public class Casa {
    private String cor;
    private double altura;
    private double largura;
    private boolean janelaAberta;
    
    public Casa(){
        
    }
    
    private void abrirAJanela(){
        this.janelaAberta=true;
    }
    
    public void status(){
        System.out.println("============SOBRE A MINHA CASA===============");
        System.out.println("Cor: "+getCor());
        System.out.println("Tamanho: "+this.altura+"x"+this.largura);
    }
    
    public String getCor(){
        return this.cor;
    }
    
    public void setCor(String color){
        this.cor=color;
    }
    
    public double getAltura(){
        return this.altura;
    }
    
    public void setAltura(double height){
        this.altura=height;
    }
    
    public double getLargura(){
        return this.largura;
    }
    
    public void setLargura(double leftToRight){
        this.largura=leftToRight;
    }
}
