package getters.setters;
public class GettersSetters {
    public static void main(String[] args) {
        Casa minhaCasa=new Casa();
        minhaCasa.setCor("Azul");
        minhaCasa.setAltura(12.41);
        minhaCasa.setLargura(10);
        minhaCasa.status();
    }
    
}
