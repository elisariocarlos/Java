/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package minhaprimeiraclasse;

/**
 *
 * @author Elisário Carlos
 */
public class Carro {
    String cor;
    String marca;
    String matricula;
    boolean ligado;
    
    void buzinar(){
        if(this.ligado==true){
          System.out.println("Piiiiii!!");
        }
        else{
            System.out.println("Primeiro ligue o carro!");
        }
    }
    
    void ligarCarro(){
        this.ligado=true;
    }
    
    void desligarCarro(){
        this.ligado=false;
    }
    
    void statusDoCarro(){
        System.out.println("Cor do carro: "+this.cor);
        System.out.println("Marca do carro: "+this.marca);
        System.out.println("Matricula do carro: "+this.matricula);
    }
}
