/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package minhaprimeiraclasse;

/**
 *
 * @author Elisário Carlos
 */
public class MinhaPrimeiraClasse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carro carro1=new Carro();
        carro1.cor="Branco";
        carro1.marca="BMW";
        carro1.matricula="US123";
        carro1.buzinar();
        carro1.statusDoCarro();
        
        System.out.println("\n");
        Carro carro2=new Carro();
        carro2.cor="Preto";
        carro2.marca="TOYOTA";
        carro2.matricula="LD12031";
        carro2.ligado=true;
        carro2.buzinar();
        carro2.statusDoCarro();
        
    }
    
}
